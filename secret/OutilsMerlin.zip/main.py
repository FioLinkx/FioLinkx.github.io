import json
import os

with open('data.json') as json_data:
    data = json.load(json_data)
with open('result.json') as json_data:
    result = json.load(json_data)

EFFET = {
    "1": "S'active à l'entrée au combat",
    "2": "S'active même en emplacement secondaire",
    "3": "S'active uniquement en JcJ",
    "4": "S'active partout, sauf en JCJ",
    "5": "S'active Uniquement en affrontement",
    "6": "S'active partout, sauf en affrontement",
    "7": "S'active partout",
    "8": "S'active uniquement en combat de bête démoniaque",
    "9": "Sauf en combat de bête démoniaque",
}

def valid(res):
    param = res.split(" ")
    if not len(param):
        return False
    for i in param:
        if not i.isdigit():
            return False
        if i not in EFFET:
            return False 
    return True
    

i = 1
while i <= len(list(data["data"])):
    os.system('cls' if os.name == 'nt' else 'clear')
    if str(i) in result:
        i += 1
        continue
    
    print("-"*50)
    print(f"\033[96m {i} - Pour {data['data'][str(i)]['name']} \033[00m (Si plusieurs effet, séparer par un espace)")
    
    print(f"\t\033[93m 2 -- {data['data'][str(i)]['passif']}")
    
    for k, v in EFFET.items():
        print(f"\t\033[92m {k}: {v}\033[00m")
    print("\t\033[91m EXIT: Sauvegarder & quitter \033[00m")
    print("\t\033[91m BACK: Revenir en arrière \033[00m")
    
    res = input("Effet >> ")
    
    if res.lower() == "exit":
        break
    if res.lower() == "back":
        i -= 1
        result.pop(str(i))
        continue
    if not valid(res):
        print("\033[91m ATTENTION: Effet incorrect \033[00m")
        continue
    
    result[str(i)] = res.split(" ")
        
    i += 1
    

with open("result.json", "w") as write_file:
    json.dump(result, write_file)